import numpy as np
from decision_tree import *

def one_hot_encode(data, categorical_columns):
    encoded_data = []
    ind = 9
    mp = {}
    for column in categorical_columns:
        for r in data:
            print(r[column])
        unique_values = set(row[column] for row in data)
        for u in unique_values:
            print(u)
            mp[u] = ind
            ind += 1

    for entry in data:
        encoded_entry = entry.copy()

        for column in categorical_columns:
            unique_values = set(row[column] for row in data)

            for value in unique_values:
                print(value)
                new_column_name = mp[value]
                encoded_entry[new_column_name] = 1 if entry[column] == value else 0

            # Remove the original categorical column
            del encoded_entry[column]

        encoded_data.append(encoded_entry)

    return encoded_data

data = np.genfromtxt('../diabetes_prediction_dataset.csv', delimiter=',')

categorical_columns = [0, 4]

# Perform one-hot encoding
# data = one_hot_encode(data, categorical_columns)
data = np.delete(data, categorical_columns, axis=1)

diabetic_data = data[data[:, -1] == 1]  
non_diabetic_data = data[data[:, -1] == 0]

# Take 1/10th of non-diabetic data
non_diabetic_data = non_diabetic_data[:len(non_diabetic_data)//10]

# Concatenate the datasets to create the final dataset
data = np.concatenate((non_diabetic_data, diabetic_data), axis=0)


np.random.seed(0)
np.random.shuffle(data)

# Splitting data into training and validation
n_samples = len(data)
train_size = int(np.ceil(2/3 * n_samples))

train_data = data[:train_size]
val_data = data[train_size:]

X_train = train_data[:, :-1]
Y_train = train_data[:, -1]
X_valid = val_data[:, :-1]
Y_valid = val_data[:, -1].astype(int)

# Pre-process the data (convert continuous features to binary)
# Ignore nan values

means = np.nanmean(X_train, axis=0)
X_train_binary = (X_train > means).astype(int)
X_valid_binary = (X_valid > means).astype(int)

# Train the decision tree model and make predictions
Y_valid_pred = myDT(X_train_binary, Y_train.astype(int), X_valid_binary)

# Evaluate performance
accuracy, confusion_matrix = evaluate_performance(Y_valid, Y_valid_pred)

precision = confusion_matrix[1][1]/ (confusion_matrix[1][1] + confusion_matrix[0][1])

recall = confusion_matrix[1][1]/ (confusion_matrix[1][1] + confusion_matrix[1][0])

print(f'Validation Accuracy: {accuracy:.4f}')
print('Confusion Matrix:')
print(confusion_matrix)

print('Precision:', precision)

print('Recall:', recall)
